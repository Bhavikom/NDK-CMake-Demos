## 编码输入长度
AmrEncoder.encode这个函数第二个参数，接受一个数组，如果是short[]，建议是长度是160；如果是byte[]，建议长度是320
