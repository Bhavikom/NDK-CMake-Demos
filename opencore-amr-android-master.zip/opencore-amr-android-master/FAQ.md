## Encode Input Length
 The second parameter of AmrEncoder.encode accept an array, it's recommended to 160 in short, or 320 in byte.
